var simpleBar = document.getElementById('simple-bar');
new SimpleBar(simpleBar, { autoHide: true });
