flatpickr(".date-picker", {
  enableTime: true,
  dateFormat: "Y-m-d H:i",
});