setTimeout(function(){ 
  $('#glassCase').glassCase({
    // 'widthDisplay': 476,
    // 'heightDisplay': 476,
    'isZoomDiffWH': 'true',
    'zoomWidth': 300,
    'zoomHeight': 300,
    'thumbsPosition': 'left',
    'isOneThumbShown': 'true',
    'isDownloadEnabled': 'false',
    'nrThumbsPerRow': '4',
    'thumbsMargin': '20',
    'data-gc-type': 'iframe',
    'zoomPosition': 'right',
  });
}, 1100);
